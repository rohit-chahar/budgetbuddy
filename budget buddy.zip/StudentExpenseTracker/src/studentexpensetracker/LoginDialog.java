package studentexpensetracker;

import javax.swing.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDialog extends JDialog {

    private int authenticatedUserId = -1;
    private String authenticatedUserName = "";

    private JTextField loginEmailField;
    private JPasswordField loginPassField;

    private JTextField regNameField;
    private JTextField regEmailField;
    private JPasswordField regPassField;

    public LoginDialog(Frame parent) {
        super(parent, "Budget Buddy - Student Authentication", true);
        setSize(420, 360);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.addTab("Login", createLoginPanel());
        tabbedPane.addTab("Sign Up", createSignUpPanel());

        add(tabbedPane, BorderLayout.CENTER);
    }

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Email Address:"), gbc);
        gbc.gridx = 1;
        loginEmailField = new JTextField(15);
        panel.add(loginEmailField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        loginPassField = new JPasswordField(15);
        panel.add(loginPassField, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        JButton loginBtn = new JButton("Login");
        loginBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        loginBtn.addActionListener(e -> processLogin());
        panel.add(loginBtn, gbc);

        return panel;
    }

    private JPanel createSignUpPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        regNameField = new JTextField(15);
        panel.add(regNameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(new JLabel("Email Address:"), gbc);
        gbc.gridx = 1;
        regEmailField = new JTextField(15);
        panel.add(regEmailField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Create Password:"), gbc);
        gbc.gridx = 1;
        regPassField = new JPasswordField(15);
        panel.add(regPassField, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        JButton signupBtn = new JButton("Create Account");
        signupBtn.setFont(new Font("SansSerif", Font.BOLD, 12));
        signupBtn.addActionListener(e -> processSignUp());
        panel.add(signupBtn, gbc);

        return panel;
    }

    private void processLogin() {
        String email = loginEmailField.getText().trim();
        String pass = new String(loginPassField.getPassword()).trim();

        if (email.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both email and password.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT id, full_name FROM users WHERE email = ? AND password = ?";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, email);
                ps.setString(2, pass);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        authenticatedUserId = rs.getInt("id");
                        authenticatedUserName = rs.getString("full_name");
                        dispose(); // Close dialog on success
                    } else {
                        JOptionPane.showMessageDialog(this, "Invalid email or password.", "Login Failed", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database connection error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void processSignUp() {
        String name = regNameField.getText().trim();
        String email = regEmailField.getText().trim();
        String pass = new String(regPassField.getPassword()).trim();

        if (name.isEmpty() || email.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            // Check for existing account
            String checkSql = "SELECT id FROM users WHERE email = ?";
            try (PreparedStatement checkPs = conn.prepareStatement(checkSql)) {
                checkPs.setString(1, email);
                try (ResultSet rs = checkPs.executeQuery()) {
                    if (rs.next()) {
                        JOptionPane.showMessageDialog(this, "An account with this email already exists.", "Registration Notice", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                }
            }

            // Insert new user
            String insertSql = "INSERT INTO users (full_name, email, password) VALUES (?, ?, ?)";
            try (PreparedStatement insertPs = conn.prepareStatement(insertSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                insertPs.setString(1, name);
                insertPs.setString(2, email);
                insertPs.setString(3, pass);
                insertPs.executeUpdate();

                try (ResultSet keys = insertPs.getGeneratedKeys()) {
                    if (keys.next()) {
                        int newUserId = keys.getInt(1);
                        // Initialize empty budget row for new user
                        String initBudgetSql = "INSERT INTO budget_settings (user_id, monthly_budget) VALUES (?, 0.0)";
                        try (PreparedStatement budgetPs = conn.prepareStatement(initBudgetSql)) {
                            budgetPs.setInt(1, newUserId);
                            budgetPs.executeUpdate();
                        }
                    }
                }
            }

            JOptionPane.showMessageDialog(this, "Account created successfully! Please sign in using the Login tab.", "Success", JOptionPane.INFORMATION_MESSAGE);
            regNameField.setText("");
            regEmailField.setText("");
            regPassField.setText("");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error during sign-up: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public int getAuthenticatedUserId() {
        return authenticatedUserId;
    }

    public String getAuthenticatedUserName() {
        return authenticatedUserName;
    }
}