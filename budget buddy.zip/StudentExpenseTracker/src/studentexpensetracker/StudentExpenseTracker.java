package studentexpensetracker;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.geom.Arc2D;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.*;

public class StudentExpenseTracker extends JFrame {

    // Active Student Session
    private final int currentUserId;
    private final String currentUserName;

    private double totalBudget = 0.0;
    private double totalExpenses = 0.0;

    // Alert threshold state flags
    private boolean warned80 = false;
    private boolean warned100 = false;

    // UI Components
    private JTextField budgetField;
    private JTextField itemField;
    private JTextField amountField;
    private JComboBox<String> categoryBox;
    private JLabel totalBudgetLabel;
    private JLabel totalSpentLabel;
    private JLabel balanceLabel;
    private DefaultTableModel tableModel;
    private JTable expenseTable;
    private PieChartPanel pieChartPanel;

    private final String[] CATEGORIES = {
        "Food & Canteen", "Books & Stationery", "Rent & PG", "Travel", "Fees", "Leisure"
    };

    public StudentExpenseTracker(int userId, String userName) {
        this.currentUserId = userId;
        this.currentUserName = userName;

        setTitle("Budget Buddy - Logged in as: " + userName);
        setSize(1000, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));

        // 1. Top Panel: Budget & Summary Cards
        JPanel topPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 5, 15));

        JPanel budgetInputPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        budgetInputPanel.add(new JLabel("Set Monthly Budget:"));
        budgetField = new JTextField(10);
        JButton setBudgetBtn = new JButton("Set Budget");
        budgetInputPanel.add(budgetField);
        budgetInputPanel.add(setBudgetBtn);

        JPanel summaryPanel = new JPanel(new GridLayout(1, 3, 15, 0));
        totalBudgetLabel = new JLabel("Budget: 0.00", SwingConstants.CENTER);
        totalSpentLabel = new JLabel("Spent: 0.00", SwingConstants.CENTER);
        balanceLabel = new JLabel("Balance: 0.00", SwingConstants.CENTER);

        formatSummaryLabel(totalBudgetLabel, new Color(220, 240, 255), Color.BLACK);
        formatSummaryLabel(totalSpentLabel, new Color(255, 230, 230), new Color(180, 0, 0));
        formatSummaryLabel(balanceLabel, new Color(230, 255, 230), new Color(0, 120, 0));

        summaryPanel.add(totalBudgetLabel);
        summaryPanel.add(totalSpentLabel);
        summaryPanel.add(balanceLabel);

        topPanel.add(budgetInputPanel);
        topPanel.add(summaryPanel);
        add(topPanel, BorderLayout.NORTH);

        // 2. Center Panel: Split Table (Left) and Pie Chart (Right)
        String[] columnNames = {"Date", "Item Description", "Category", "Amount"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        expenseTable = new JTable(tableModel);
        expenseTable.setRowHeight(24);
        JScrollPane scrollPane = new JScrollPane(expenseTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Expense History"));

        pieChartPanel = new PieChartPanel();
        pieChartPanel.setPreferredSize(new Dimension(380, 300));
        pieChartPanel.setBorder(BorderFactory.createTitledBorder("Category Breakdown"));

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, scrollPane, pieChartPanel);
        splitPane.setResizeWeight(0.6);
        add(splitPane, BorderLayout.CENTER);

        // 3. Bottom Panel: Entry Controls
        JPanel bottomPanel = new JPanel(new BorderLayout(5, 5));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(5, 15, 10, 15));

        JPanel formPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 8, 5));
        formPanel.add(new JLabel("Item:"));
        itemField = new JTextField(9);
        formPanel.add(itemField);

        formPanel.add(new JLabel("Category:"));
        categoryBox = new JComboBox<>(CATEGORIES);
        formPanel.add(categoryBox);

        formPanel.add(new JLabel("Amount:"));
        amountField = new JTextField(7);
        formPanel.add(amountField);

        JButton addBtn = new JButton("Add Expense");
        JButton deleteBtn = new JButton("Delete Selected");
        formPanel.add(addBtn);
        formPanel.add(deleteBtn);

        bottomPanel.add(formPanel, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Listeners
        setBudgetBtn.addActionListener(e -> setBudget());
        addBtn.addActionListener(e -> addExpense());
        deleteBtn.addActionListener(e -> deleteExpense());

        // Load logged-in student's records from MySQL
        loadUserDataFromDB();
    }

    private void formatSummaryLabel(JLabel label, Color bg, Color fg) {
        label.setOpaque(true);
        label.setBackground(bg);
        label.setForeground(fg);
        label.setFont(new Font("SansSerif", Font.BOLD, 14));
        label.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
    }

    private void loadUserDataFromDB() {
        try (Connection conn = DBConnection.getConnection()) {
            // Fetch student's budget
            String sqlBudget = "SELECT monthly_budget FROM budget_settings WHERE user_id = ?";
            try (PreparedStatement ps = conn.prepareStatement(sqlBudget)) {
                ps.setInt(1, currentUserId);
                try (ResultSet rs = ps.executeQuery()) {
                    if (rs.next()) {
                        totalBudget = rs.getDouble("monthly_budget");
                    }
                }
            }

            // Fetch student's expenses
            String sqlExpenses = "SELECT expense_date, item_title, category, amount FROM expenses WHERE user_id = ? ORDER BY id ASC";
            try (PreparedStatement ps = conn.prepareStatement(sqlExpenses)) {
                ps.setInt(1, currentUserId);
                try (ResultSet rs = ps.executeQuery()) {
                    totalExpenses = 0.0;
                    tableModel.setRowCount(0);

                    while (rs.next()) {
                        String date = rs.getString("expense_date");
                        String item = rs.getString("item_title");
                        String cat = rs.getString("category");
                        double amt = rs.getDouble("amount");

                        tableModel.addRow(new Object[]{date, item, cat, String.format("%.2f", amt)});
                        totalExpenses += amt;
                    }
                }
            }
            updateSummaries();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database Connection Error: " + ex.getMessage(),
                    "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void setBudget() {
        try {
            double value = Double.parseDouble(budgetField.getText().trim());
            if (value <= 0) throw new NumberFormatException();

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO budget_settings (user_id, monthly_budget) VALUES (?, ?) "
                           + "ON DUPLICATE KEY UPDATE monthly_budget = VALUES(monthly_budget)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, currentUserId);
                    ps.setDouble(2, value);
                    ps.executeUpdate();
                }

                totalBudget = value;
                warned80 = false;
                warned100 = false;
                updateSummaries();
                checkBudgetAlerts();
                budgetField.setText("");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter a valid positive number for budget.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error saving budget: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addExpense() {
        String item = itemField.getText().trim();
        String category = (String) categoryBox.getSelectedItem();
        String amountStr = amountField.getText().trim();

        if (item.isEmpty() || amountStr.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter both item description and amount.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double amount = Double.parseDouble(amountStr);
            if (amount <= 0) throw new NumberFormatException();

            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

            try (Connection conn = DBConnection.getConnection()) {
                String sql = "INSERT INTO expenses (user_id, expense_date, item_title, category, amount) VALUES (?, ?, ?, ?, ?)";
                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setInt(1, currentUserId);
                    ps.setString(2, date);
                    ps.setString(3, item);
                    ps.setString(4, category);
                    ps.setDouble(5, amount);
                    ps.executeUpdate();
                }

                tableModel.addRow(new Object[]{date, item, category, String.format("%.2f", amount)});
                totalExpenses += amount;
                updateSummaries();
                checkBudgetAlerts();

                itemField.setText("");
                amountField.setText("");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Enter a valid positive number for amount.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error inserting expense: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteExpense() {
        int selectedRow = expenseTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Select an expense from the table to delete.", "Notice", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String item = (String) tableModel.getValueAt(selectedRow, 1);
        double amount = Double.parseDouble((String) tableModel.getValueAt(selectedRow, 3));

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM expenses WHERE item_title = ? AND amount = ? AND user_id = ? LIMIT 1";
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, item);
                ps.setDouble(2, amount);
                ps.setInt(3, currentUserId);
                ps.executeUpdate();
            }

            tableModel.removeRow(selectedRow);
            totalExpenses -= amount;
            updateSummaries();
            checkBudgetAlerts();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting record: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateSummaries() {
        double balance = totalBudget - totalExpenses;
        totalBudgetLabel.setText(String.format("Budget: %.2f", totalBudget));
        totalSpentLabel.setText(String.format("Spent: %.2f", totalExpenses));
        balanceLabel.setText(String.format("Balance: %.2f", balance));

        if (balance < 0) {
            balanceLabel.setForeground(Color.RED);
        } else {
            balanceLabel.setForeground(new Color(0, 120, 0));
        }

        // Aggregate for Pie Chart
        Map<String, Double> categoryTotals = new HashMap<>();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String cat = (String) tableModel.getValueAt(i, 2);
            double amt = Double.parseDouble((String) tableModel.getValueAt(i, 3));
            categoryTotals.put(cat, categoryTotals.getOrDefault(cat, 0.0) + amt);
        }
        pieChartPanel.setData(categoryTotals, totalExpenses);
    }

    private void checkBudgetAlerts() {
        if (totalBudget <= 0) return;

        double spentRatio = totalExpenses / totalBudget;

        if (spentRatio >= 1.0 && !warned100) {
            warned100 = true;
            warned80 = true;
            JOptionPane.showMessageDialog(
                this,
                String.format("Critical Budget Alert!\nYou have reached %.1f%% of your budget.\nTotal Spent: %.2f / %.2f",
                        spentRatio * 100, totalExpenses, totalBudget),
                "Budget Exceeded",
                JOptionPane.ERROR_MESSAGE
            );
        } else if (spentRatio >= 0.8 && !warned80) {
            warned80 = true;
            JOptionPane.showMessageDialog(
                this,
                String.format("Budget Warning!\nYou have spent %.1f%% of your monthly budget.\nRemaining Balance: %.2f",
                        spentRatio * 100, (totalBudget - totalExpenses)),
                "Approaching Budget Limit",
                JOptionPane.WARNING_MESSAGE
            );
        } else {
            if (spentRatio < 0.8) {
                warned80 = false;
                warned100 = false;
            } else if (spentRatio < 1.0) {
                warned100 = false;
            }
        }
    }

    // --- Main Entry Point ---
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginDialog loginDialog = new LoginDialog(null);
            loginDialog.setVisible(true);

            // Open dashboard only if login or signup succeeded
            if (loginDialog.getAuthenticatedUserId() != -1) {
                new StudentExpenseTracker(
                    loginDialog.getAuthenticatedUserId(),
                    loginDialog.getAuthenticatedUserName()
                ).setVisible(true);
            } else {
                System.exit(0);
            }
        });
    }
}

/**
 * Custom 2D Pie Chart Panel
 */
class PieChartPanel extends JPanel {

    private Map<String, Double> data = new HashMap<>();
    private double total = 0.0;

    private final Color[] SLICE_COLORS = {
        new Color(79, 129, 189),
        new Color(192, 80, 77),
        new Color(155, 187, 89),
        new Color(128, 100, 162),
        new Color(75, 172, 198),
        new Color(247, 150, 70),
        new Color(165, 165, 165)
    };

    public void setData(Map<String, Double> data, double total) {
        this.data = data;
        this.total = total;
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (total <= 0 || data.isEmpty()) {
            g2.setColor(Color.GRAY);
            g2.setFont(new Font("SansSerif", Font.ITALIC, 14));
            String msg = "No expenses recorded yet";
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(msg, (getWidth() - fm.stringWidth(msg)) / 2, getHeight() / 2);
            g2.dispose();
            return;
        }

        int diameter = Math.min(getWidth() - 30, (getHeight() / 2) + 20);
        int x = (getWidth() - diameter) / 2;
        int y = 20;

        double currentAngle = 90.0;
        int colorIdx = 0;

        for (Map.Entry<String, Double> entry : data.entrySet()) {
            double sliceAngle = (entry.getValue() / total) * 360.0;
            g2.setColor(SLICE_COLORS[colorIdx % SLICE_COLORS.length]);
            g2.fill(new Arc2D.Double(x, y, diameter, diameter, currentAngle, sliceAngle, Arc2D.PIE));
            g2.setColor(Color.WHITE);
            g2.draw(new Arc2D.Double(x, y, diameter, diameter, currentAngle, sliceAngle, Arc2D.PIE));

            currentAngle += sliceAngle;
            colorIdx++;
        }

        int legendY = y + diameter + 30;
        int legendX = 25;
        colorIdx = 0;
        g2.setFont(new Font("SansSerif", Font.PLAIN, 12));

        for (Map.Entry<String, Double> entry : data.entrySet()) {
            double percent = (entry.getValue() / total) * 100.0;

            g2.setColor(SLICE_COLORS[colorIdx % SLICE_COLORS.length]);
            g2.fillRect(legendX, legendY - 10, 12, 12);
            g2.setColor(Color.DARK_GRAY);
            g2.drawRect(legendX, legendY - 10, 12, 12);

            g2.setColor(Color.BLACK);
            String label = String.format("%s (%.1f%%)", entry.getKey(), percent);
            g2.drawString(label, legendX + 18, legendY);

            legendY += 20;
            colorIdx++;
        }

        g2.dispose();
    }
}